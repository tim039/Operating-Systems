#ifndef mycp_h
#define mycp_h
#define BUFFERSIZE 128

void copy(char *fileName1, char *fileName2);


#endif
