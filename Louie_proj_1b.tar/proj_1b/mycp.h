/*mycp.h
By: Timothy Louie
written:9/10/2018
Updated: 9/14/2018
mycp.h is the header file for mycp.c
*/

#ifndef mycp_h
#define mycp_h
#define BUFFERSIZE 128

void copy(char *fileName1, char *fileName2);


#endif
